export interface ServiceFeature {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface ServiceTier {
  id: string;
  name: string;
  price: number;
  features: string[];
  isPopular?: boolean;
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  features: ServiceFeature[];
  tiers?: ServiceTier[];
}