export const products = [
  // Electronics
  {
    id: 'e1',
    name: 'Smart 4K OLED TV',
    category: 'Electronics',
    price: 1299.99,
    originalPrice: 1499.99,
    description: 'Experience stunning picture quality with this 65-inch OLED TV featuring AI-powered upscaling and HDR.',
    features: ['4K Resolution', 'HDR Support', 'Smart TV Features', 'Voice Control', 'AI Upscaling'],
    image: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    reviews: 245,
    stock: 15,
    specifications: {
      'Screen Size': '65 inches',
      'Resolution': '3840 x 2160',
      'HDR': 'Yes',
      'Smart TV': 'Yes',
    }
  },
  {
    id: 'e2',
    name: 'Pro Wireless Headphones',
    category: 'Electronics',
    price: 299.99,
    originalPrice: 349.99,
    description: 'Premium noise-cancelling wireless headphones with spatial audio',
    features: ['Active Noise Cancellation', 'Bluetooth 5.0', '30-hour Battery Life', 'Spatial Audio'],
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    reviews: 189,
    stock: 25,
    specifications: {
      'Type': 'Over-ear',
      'Battery Life': '30 hours',
      'Noise Cancellation': 'Yes',
      'Wireless': 'Yes',
    }
  },
  {
    id: 'e3',
    name: 'Smart Watch Pro',
    category: 'Electronics',
    price: 399.99,
    originalPrice: 449.99,
    description: 'Advanced smartwatch with health monitoring and cellular connectivity',
    features: ['Heart Rate Monitor', 'ECG', 'GPS', 'Cellular', 'Water Resistant'],
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    reviews: 320,
    stock: 30,
    specifications: {
      'Display': 'OLED',
      'Battery Life': '18 hours',
      'Water Resistance': '50m',
      'Connectivity': '4G LTE',
    }
  },
  // Add more electronics...

  // Fashion
  {
    id: 'f1',
    name: 'Premium Leather Jacket',
    category: 'Fashion',
    price: 199.99,
    originalPrice: 249.99,
    description: 'Genuine leather jacket with modern design and premium finish',
    features: ['100% Genuine Leather', 'Multiple Pockets', 'Quilted Lining', 'Water Resistant'],
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    reviews: 156,
    stock: 20,
    specifications: {
      'Material': 'Genuine Leather',
      'Fit': 'Regular',
      'Style': 'Casual',
      'Care': 'Dry Clean Only',
    }
  },
  {
    id: 'f2',
    name: 'Designer Sunglasses',
    category: 'Fashion',
    price: 159.99,
    originalPrice: 189.99,
    description: 'Premium polarized sunglasses with UV protection',
    features: ['Polarized Lenses', 'UV Protection', 'Lightweight Frame', 'Case Included'],
    image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80',
    rating: 4.5,
    reviews: 89,
    stock: 35,
    specifications: {
      'Frame Material': 'Acetate',
      'Lens': 'Polarized',
      'UV Protection': 'Yes',
      'Style': 'Aviator',
    }
  },
  // Add more fashion items...

  // Home & Living
  {
    id: 'h1',
    name: 'Smart LED Ceiling Light',
    category: 'Home & Living',
    price: 129.99,
    originalPrice: 159.99,
    description: 'Smart LED ceiling light with app control and voice commands',
    features: ['Voice Control', 'App Control', 'Color Changing', 'Schedule Setting'],
    image: 'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?auto=format&fit=crop&w=800&q=80',
    rating: 4.4,
    reviews: 78,
    stock: 40,
    specifications: {
      'Wattage': '24W',
      'Lumens': '2400lm',
      'Color Temperature': '2700K-6500K',
      'Smart Features': 'Yes',
    }
  },
  // Add more home & living items...

  // Beauty
  {
    id: 'b1',
    name: 'Premium Skincare Set',
    category: 'Beauty',
    price: 89.99,
    originalPrice: 119.99,
    description: 'Complete skincare routine with natural ingredients',
    features: ['Natural Ingredients', 'Dermatologist Tested', 'Fragrance Free', 'Suitable for All Skin Types'],
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    reviews: 234,
    stock: 50,
    specifications: {
      'Skin Type': 'All Types',
      'Package Contents': '5 Items',
      'Organic': 'Yes',
      'Volume': '500ml Total',
    }
  },
  // Add more beauty products...

  // Groceries
  {
    id: 'g1',
    name: 'Organic Food Bundle',
    category: 'Groceries',
    price: 79.99,
    originalPrice: 99.99,
    description: 'Premium selection of organic fruits, vegetables, and grains',
    features: ['100% Organic', 'Fresh Produce', 'Local Sourced', 'Seasonal Items'],
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    reviews: 167,
    stock: 30,
    specifications: {
      'Type': 'Organic',
      'Items': '15+ Products',
      'Storage': 'Refrigerated',
      'Shelf Life': '1 Week',
    }
  },
  // Add more grocery items...

  // Sports
  {
    id: 's1',
    name: 'Smart Fitness Watch',
    category: 'Sports',
    price: 199.99,
    originalPrice: 249.99,
    description: 'Advanced fitness tracker with GPS and heart rate monitoring',
    features: ['Heart Rate Monitor', 'GPS Tracking', 'Water Resistant', 'Sleep Tracking'],
    image: 'https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    reviews: 312,
    stock: 45,
    specifications: {
      'Battery Life': '7 days',
      'Water Resistance': '50m',
      'Display': 'AMOLED',
      'Compatibility': 'iOS/Android',
    }
  },
  // Add more sports items...
];