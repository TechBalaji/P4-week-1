import {
  Package,
  Headphones,
  Gift,
  Truck,
  Wallet,
  Shield,
  Clock,
  Zap,
  Smartphone,
  Heart,
  MapPin,
  CreditCard,
  Box,
  Award,
  Tool,
} from 'lucide-react';

export const serviceCategories = [
  {
    id: 'delivery',
    name: 'Smart Delivery',
    description: 'Advanced delivery solutions for modern shopping',
    features: [
      {
        id: 'same-day',
        name: 'Same-Day Delivery',
        description: 'Get your items delivered within hours',
        icon: 'Truck'
      },
      {
        id: 'live-tracking',
        name: 'Live Tracking',
        description: 'Real-time package tracking with live map view',
        icon: 'MapPin'
      },
      {
        id: 'scheduled',
        name: 'Scheduled Delivery',
        description: 'Choose your preferred delivery time slot',
        icon: 'Clock'
      }
    ],
    tiers: [
      {
        id: 'basic',
        name: 'Basic Delivery',
        price: 0,
        features: ['Standard 3-5 day delivery', 'Order tracking', 'SMS updates']
      },
      {
        id: 'premium',
        name: 'Premium Delivery',
        price: 9.99,
        features: ['Same-day delivery', 'Live tracking', 'Time slot selection', 'Priority support'],
        isPopular: true
      }
    ]
  },
  {
    id: 'protection',
    name: 'Smart Protection',
    description: 'Comprehensive protection for your purchases',
    features: [
      {
        id: 'extended-warranty',
        name: 'Extended Warranty',
        description: 'Additional protection beyond standard warranty',
        icon: 'Shield'
      },
      {
        id: 'damage-protection',
        name: 'Damage Protection',
        description: 'Coverage against accidental damage',
        icon: 'Tool'
      },
      {
        id: 'theft-protection',
        name: 'Theft Protection',
        description: 'Protection against theft and loss',
        icon: 'Lock'
      }
    ]
  },
  {
    id: 'membership',
    name: 'Smart Membership',
    description: 'Exclusive benefits for members',
    features: [
      {
        id: 'rewards',
        name: 'Smart Rewards',
        description: 'Earn points on every purchase',
        icon: 'Gift'
      },
      {
        id: 'early-access',
        name: 'Early Access',
        description: 'Shop new arrivals before others',
        icon: 'Zap'
      },
      {
        id: 'premium-support',
        name: 'Premium Support',
        description: '24/7 priority customer service',
        icon: 'Headphones'
      }
    ],
    tiers: [
      {
        id: 'silver',
        name: 'Silver',
        price: 4.99,
        features: ['5% cashback', 'Free standard delivery', 'Member-only deals']
      },
      {
        id: 'gold',
        name: 'Gold',
        price: 9.99,
        features: ['10% cashback', 'Free premium delivery', 'Early access to sales', 'Premium support'],
        isPopular: true
      },
      {
        id: 'platinum',
        name: 'Platinum',
        price: 19.99,
        features: ['15% cashback', 'All Gold benefits', 'Concierge service', 'Extended returns']
      }
    ]
  }
];