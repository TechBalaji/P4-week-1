import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Categories from './components/Categories';
import { CartProvider } from './components/cart/CartProvider';
import CartDrawer from './components/cart/CartDrawer';
import ProductGrid from './components/products/ProductGrid';
import { products } from './data/products';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <CartProvider>
      <div className="min-h-screen bg-gray-50">
        <Navbar onCartClick={() => setIsCartOpen(true)} />
        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
        <main>
          <Hero />
          <Services />
          <Categories onCategorySelect={setSelectedCategory} />
          <ProductGrid
            products={products}
            category={selectedCategory ?? undefined}
          />
        </main>
      </div>
    </CartProvider>
  );
}

export default App;