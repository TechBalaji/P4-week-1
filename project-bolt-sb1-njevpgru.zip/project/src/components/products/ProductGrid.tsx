import React, { useState } from 'react';
import { Product } from '../../types';
import ProductCard from './ProductCard';
import ProductDetails from './ProductDetails';

interface ProductGridProps {
  products: Product[];
  category?: string;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, category }) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = category
    ? products.filter((product) => product.category === category)
    : products;

  return (
    <div className="py-8">
      {selectedProduct ? (
        <div className="container mx-auto px-4">
          <ProductDetails
            product={selectedProduct}
            onBack={() => setSelectedProduct(null)}
          />
        </div>
      ) : (
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={() => setSelectedProduct(product)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;