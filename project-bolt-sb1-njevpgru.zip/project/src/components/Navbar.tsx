import React, { useState } from 'react';
import { Search, ShoppingCart, User, Heart, Bell, Menu, X, Package, Headphones, Gift, Truck, Wallet } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-indigo-600 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <h1 className="text-2xl font-bold">SmartMart</h1>
            <div className="hidden md:flex items-center bg-white rounded-lg w-96">
              <input
                type="text"
                placeholder="Search for products, brands and more..."
                className="w-full px-4 py-2 text-gray-800 rounded-l-lg focus:outline-none"
              />
              <button className="px-4 py-2 bg-indigo-700 rounded-r-lg">
                <Search className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <button className="flex items-center space-x-1 hover:text-indigo-200">
              <User className="w-5 h-5" />
              <span>Account</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-indigo-200">
              <Heart className="w-5 h-5" />
              <span>Wishlist</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-indigo-200">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-indigo-200">
              <ShoppingCart className="w-5 h-5" />
              <span>Cart</span>
            </button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-indigo-700 px-4 py-2">
          <div className="space-y-2">
            <button className="flex items-center space-x-2 w-full py-2 hover:bg-indigo-600 px-2 rounded">
              <User className="w-5 h-5" />
              <span>Account</span>
            </button>
            <button className="flex items-center space-x-2 w-full py-2 hover:bg-indigo-600 px-2 rounded">
              <Heart className="w-5 h-5" />
              <span>Wishlist</span>
            </button>
            <button className="flex items-center space-x-2 w-full py-2 hover:bg-indigo-600 px-2 rounded">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </button>
            <button className="flex items-center space-x-2 w-full py-2 hover:bg-indigo-600 px-2 rounded">
              <ShoppingCart className="w-5 h-5" />
              <span>Cart</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;