import React from 'react';
import { Package, Headphones, Gift, Truck, Wallet, Shield, Clock, Zap } from 'lucide-react';

const services = [
  {
    icon: <Package className="w-8 h-8" />,
    title: 'Smart Delivery',
    description: 'Same-day delivery with real-time tracking',
  },
  {
    icon: <Gift className="w-8 h-8" />,
    title: 'Premium Services',
    description: 'Exclusive membership benefits and rewards',
  },
  {
    icon: <Headphones className="w-8 h-8" />,
    title: '24/7 Support',
    description: 'Round-the-clock customer assistance',
  },
  {
    icon: <Wallet className="w-8 h-8" />,
    title: 'Smart Financing',
    description: 'Flexible payment options and EMI',
  },
  {
    icon: <Shield className="w-8 h-8" />,
    title: 'Secure Shopping',
    description: 'Enhanced security for safe transactions',
  },
  {
    icon: <Clock className="w-8 h-8" />,
    title: 'Flash Deals',
    description: 'Time-limited exclusive offers',
  },
  {
    icon: <Truck className="w-8 h-8" />,
    title: 'Easy Returns',
    description: 'Hassle-free 30-day returns',
  },
  {
    icon: <Zap className="w-8 h-8" />,
    title: 'Quick Compare',
    description: 'Advanced product comparison tools',
  },
];

const Services = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Enhanced Services for Smart Shopping
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Experience shopping like never before with our innovative services designed to make your life easier.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="text-indigo-600 mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;