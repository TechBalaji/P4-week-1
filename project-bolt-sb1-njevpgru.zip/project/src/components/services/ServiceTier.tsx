import React from 'react';
import { Check } from 'lucide-react';
import { ServiceTier as ServiceTierType } from '../../types/services';

interface ServiceTierProps {
  tier: ServiceTierType;
}

const ServiceTier: React.FC<ServiceTierProps> = ({ tier }) => {
  return (
    <div className={`rounded-lg p-6 ${
      tier.isPopular ? 'bg-indigo-50 border-2 border-indigo-500' : 'bg-white border border-gray-200'
    }`}>
      {tier.isPopular && (
        <span className="inline-block px-3 py-1 text-xs font-semibold text-indigo-600 bg-indigo-100 rounded-full mb-4">
          Most Popular
        </span>
      )}
      <h3 className="text-xl font-bold text-gray-900">{tier.name}</h3>
      <p className="mt-4 text-3xl font-bold text-gray-900">
        ${tier.price}
        <span className="text-base font-normal text-gray-500">/month</span>
      </p>
      <ul className="mt-6 space-y-4">
        {tier.features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <Check className="h-5 w-5 text-indigo-500 mr-2" />
            <span className="text-gray-600">{feature}</span>
          </li>
        ))}
      </ul>
      <button className={`mt-8 w-full py-3 px-4 rounded-lg font-semibold ${
        tier.isPopular
          ? 'bg-indigo-600 text-white hover:bg-indigo-700'
          : 'bg-white text-indigo-600 border border-indigo-600 hover:bg-indigo-50'
      }`}>
        Choose {tier.name}
      </button>
    </div>
  );
};