import React from 'react';
import { serviceCategories } from '../../data/services';
import ServiceCategory from './ServiceCategory';

const Services = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Smart Services for Smart Shopping
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Experience shopping like never before with our innovative services designed to make your life easier.
          </p>
        </div>

        {serviceCategories.map((category) => (
          <ServiceCategory key={category.id} category={category} />
        ))}
      </div>
    </section>
  );
};

export default Services;