import React from 'react';
import { ServiceCategory as ServiceCategoryType } from '../../types/services';
import ServiceFeature from './ServiceFeature';
import ServiceTier from './ServiceTier';

interface ServiceCategoryProps {
  category: ServiceCategoryType;
}

const ServiceCategory: React.FC<ServiceCategoryProps> = ({ category }) => {
  return (
    <div className="py-12">
      <div className="text-center mb-12">
        <h3 className="text-2xl font-bold text-gray-900">{category.name}</h3>
        <p className="mt-2 text-gray-600">{category.description}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-12">
        {category.features.map((feature) => (
          <ServiceFeature key={feature.id} feature={feature} />
        ))}
      </div>

      {category.tiers && (
        <div className="grid gap-8 md:grid-cols-3 mt-12">
          {category.tiers.map((tier) => (
            <ServiceTier key={tier.id} tier={tier} />
          ))}
        </div>
      )}
    </div>
  );
};