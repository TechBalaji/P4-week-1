import React from 'react';
import * as Icons from 'lucide-react';
import { ServiceFeature as ServiceFeatureType } from '../../types/services';

interface ServiceFeatureProps {
  feature: ServiceFeatureType;
}

const ServiceFeature: React.FC<ServiceFeatureProps> = ({ feature }) => {
  const Icon = Icons[feature.icon as keyof typeof Icons];

  return (
    <div className="flex items-start space-x-4 p-4 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
      <div className="flex-shrink-0">
        <div className="p-2 bg-indigo-100 rounded-lg">
          {Icon && <Icon className="w-6 h-6 text-indigo-600" />}
        </div>
      </div>
      <div>
        <h4 className="text-lg font-semibold text-gray-900">{feature.name}</h4>
        <p className="mt-1 text-gray-600">{feature.description}</p>
      </div>
    </div>
  );
};